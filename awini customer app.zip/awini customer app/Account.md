# Account
In account tabs customer can check they information and other option
![](assets/img/Account/account_tabbar.jpg)

## Profile
Review data which is:
- first name 
- last naem 
- phone number
- email 
![](assets/img/Account/profile.jpg)

#### Change password
Require to change password 
- old password 
- new password 
- confirmation new password
> password should be between 6 to 14 letters  
![](assets/img/Account/change_password.jpg)

#### Change email
Required to change email 
Simply by entering new email customer can change it
![](assets/img/Account/change_email.jpg)

## Credits 
Review wallet balance
![](assets/img/Account/wallet.jpg)

## Notifications 
In case there are an news or advertisement will appear in this list
![](assets/img/Account/notification.jpg)

## Support 
Support page is where customer can get information  of FAQ, live chat support. Social media pages
![](assets/img/Account/support.jpg)

#### FAQ
A list of frequent questions
![](assets/img/Account/faq.jpg)

#### live support 
Customer can live chat with customer support team by sending messages, or images
![](assets/img/Account/live_chat.jpg)

## Settings
![](assets/img/Account/settings.jpg)

#### Privacy policy
On click on this row will open the AWINI website privacy page
#### Terms & conditions
This also will open AWINI website on Terms page
#### About us

## Become a provider 
It’s open driver application at app store or google play store to download

## Log out
To sign out of current account
